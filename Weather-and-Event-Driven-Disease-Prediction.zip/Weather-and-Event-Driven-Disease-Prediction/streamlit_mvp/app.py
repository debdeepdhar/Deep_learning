# app.py — single-render corrected (no duplicate tables, single st_folium call)
import os
import requests
import joblib
import pandas as pd
import streamlit as st
from dotenv import load_dotenv
from geopy.geocoders import Nominatim
from streamlit_folium import st_folium
import folium
from services.weather import fetch_current_weather, fetch_aqi, fetch_onecall_uv
from services.events_calendar import load_event_calendar, get_event_multipliers
from services.seasonal import get_season_multipliers

# --- Ensure EVENT_CALENDAR exists (safe guard) ---
try:
    EVENT_CALENDAR
except NameError:
    try:
        EVENT_CALENDAR = load_event_calendar()
    except Exception:
        EVENT_CALENDAR = {}
# --------------------------------------------------

# ------------------------------
# MONTHLY RISK PROFILE (text + table + chart)
# ------------------------------
import datetime
import matplotlib.pyplot as plt

def compute_monthly_profile(lat, lon, calendar, seasons_func):
    """
    Compute monthly risk multipliers for months 1..12.
    Returns:
      - months (list of month numbers)
      - disease_keys (sorted list)
      - month_scores dict: {disease_key: [score for month1..12]}
    Logic:
      - For each month, create a dummy date (15th of month) and get:
          * seasonal multipliers from seasons_func (expects lat, lon)
          * event multipliers from calendar using get_event_multipliers(calendar, date)
      - Combine multipliers by multiplication for each disease key.
      - Baseline score = 0.1 (arbitrary small baseline), final = baseline * multiplier
    """
    months = list(range(1,13))
    # gather all possible disease keys from calendar + seasonal definitions
    keys = set()
    # from calendar effects
    for ev in (calendar or {}).values():
        for k in ev.get("effects", {}).keys():
            keys.add(k.lower())
    # from seasonal multipliers (pull keys from SEASON_MULTIPLIERS via seasons_func by checking a sample)
    # we call seasons_func with actual lat/lon for one month; but to get all keys, check all months
    for m in months:
        d = datetime.date(datetime.date.today().year, m, 15)
        smults, _ = get_season_multipliers(lat, lon)  # uses current date internally; we'll override below by monkeypatching get_month_day? Simpler: compute season keys from global SEASON_MULTIPLIERS file is complex.
        # Instead, rely on seasonal keys present in services.seasonal.SEASON_MULTIPLIERS if available
    try:
        # try to import the SEASON_MULTIPLIERS dict (works if services.seasonal created)
        from services import seasonal as _seasonal_mod
        for sdict in getattr(_seasonal_mod, "SEASON_MULTIPLIERS", {}).values():
            for k in sdict.keys():
                keys.add(k.lower())
    except Exception:
        pass

    # prepare month_scores
    month_scores = {k: [0.0]*12 for k in sorted(keys)}
    baseline = 0.05  # small baseline probability to show on chart (adjustable)

    for i, m in enumerate(months):
        dt = datetime.date(datetime.date.today().year, m, 15)
        # get event multipliers for that date
        ev_mults, ev_matched = get_event_multipliers(calendar, date=dt)
        # get seasonal multipliers for that month by temporarily mocking date:
        # services.seasonal.get_season_multipliers uses today's date internally;
        # to approximate seasonal effect for month m we'll call helper by temporarily replacing date.today is messy.
        # Simpler approach: call get_season_multipliers using lat/lon but change the system date is not possible.
        # Instead, infer season by creating a small function that mirrors services.seasonal logic here:
        from services.seasonal import indian_season, global_season, is_india
        # determine pseudo-season key for month m
        if is_india(lat, lon):
            # map month to Indian season name (same logic as seasonal.py)
            if m in [3,4,5]:
                season_name = "Summer_India"
            elif m in [6,7,8,9]:
                season_name = "Monsoon_India" if m in [6,7,8,9] else "Monsoon_India"
            elif m == 10:
                season_name = "PostMonsoon_India"
            else:
                season_name = "Winter_India"
        else:
            # global mapping
            # Northern hemisphere assumed for simplicity of month mapping
            # determine by latitude sign
            if lat >= 0:
                if m in [12,1,2]:
                    season_name = "Winter_Global"
                elif m in [3,4,5]:
                    season_name = "Spring_Global"
                elif m in [6,7,8]:
                    season_name = "Summer_Global"
                else:
                    season_name = "Autumn_Global"
            else:
                # Southern hemisphere
                if m in [12,1,2]:
                    season_name = "Summer_Global"
                elif m in [3,4,5]:
                    season_name = "Autumn_Global"
                elif m in [6,7,8]:
                    season_name = "Winter_Global"
                else:
                    season_name = "Spring_Global"

        # attempt to get season multipliers dict from seasonal module
        try:
            from services.seasonal import SEASON_MULTIPLIERS
            season_mults = SEASON_MULTIPLIERS.get(season_name, {})
        except Exception:
            season_mults = {}

        # combine for each key
        for k in month_scores.keys():
            factor = 1.0
            # apply season factor if present
            if k in [kk.lower() for kk in season_mults.keys()]:
                factor *= float(season_mults.get(k, 1.0))
            # apply event factor if present
            if k in ev_mults:
                factor *= float(ev_mults.get(k, 1.0))
            # final score (baseline * combined_factor)
            month_scores[k][i] = baseline * factor

    return months, sorted(month_scores.keys()), month_scores

# UI: Add selection and chart rendering
with st.expander("Show monthly spikes (seasonal & calendar-based estimator)", expanded=False):
    st.markdown("This shows months when diseases/injuries are likely to spike (rule-based estimate). Choose diseases below to plot.")
    # ensure we have lat/lon
    lat = st.session_state.get("last_lat")
    lon = st.session_state.get("last_lon")
    if lat is None or lon is None:
        st.info("Run a prediction (enter a location and click 'Check risk') to enable monthly spikes view.")
    else:
        months, disease_keys, month_scores = compute_monthly_profile(lat, lon, EVENT_CALENDAR, get_season_multipliers)
        # show top keys and a small table of monthly peaks
        df_table = pd.DataFrame({k: month_scores[k] for k in disease_keys}, index=[datetime.date(1900, m, 1).strftime("%b") for m in months])
        st.write("**Estimated monthly risk table (baseline scaled)**")
        st.dataframe(df_table.style.format("{:.3f}"))

        # multiselect diseases to plot
        to_plot = st.multiselect("Pick disease(s) to plot", options=disease_keys, default=disease_keys[:3])
        if to_plot:
            # build matplotlib figure
            fig, ax = plt.subplots(figsize=(10,4))
            x = [datetime.date(1900, m, 1).strftime("%b") for m in months]
            for key in to_plot:
                ax.plot(x, month_scores[key], marker='o', label=key)
            ax.set_title("Estimated monthly relative risk (baseline * multipliers)")
            ax.set_ylabel("Relative score (arbitrary units)")
            ax.set_xlabel("Month")
            ax.grid(True)
            ax.legend()
            st.pyplot(fig)

# load calendar once
try:
    EVENT_CALENDAR = load_event_calendar()
except Exception:
    EVENT_CALENDAR = {}

# Config
load_dotenv(dotenv_path=".env")
OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY", "")
MODEL_PATH = "model/disease_predictor_clean.joblib"


# Load model
def load_model(path=MODEL_PATH):
    if not os.path.exists(path):
        return None, None
    try:
        payload = joblib.load(path)
        return payload.get("model"), payload.get("classes")
    except Exception:
        return None, None

model, classes = load_model()

# Page
st.set_page_config(page_title="Weather & Events driven Disease Risk Predictor", layout="wide")
st.title("🌤️ Weather & Events driven Disease & Injury Risk Predictor")

# Session state defaults
if "last_lat" not in st.session_state:
    st.session_state.last_lat = None
if "last_lon" not in st.session_state:
    st.session_state.last_lon = None
if "last_city" not in st.session_state:
    st.session_state.last_city = ""
if "last_results" not in st.session_state:
    st.session_state.last_results = None
if "last_X" not in st.session_state:
    st.session_state.last_X = None

col1, col2 = st.columns([1, 2])

# LEFT column: input + compute only (do NOT render results here)
with col1:
    st.subheader("Input Location")
    city = st.text_input("City or Location", value=st.session_state.last_city or "Delhi, India")
    if st.button("Check risk"):
        # reset previous
        st.session_state.last_results = None
        st.session_state.last_X = None

        # geocode
        geolocator = Nominatim(user_agent="weather_app")
        location = geolocator.geocode(city, timeout=10)
        if not location:
            st.error("❌ Location not found. Try a different query (e.g., 'Bangalore, India').")
        else:
            lat, lon = location.latitude, location.longitude
            st.session_state.last_lat = lat
            st.session_state.last_lon = lon
            st.session_state.last_city = city

            # Fetch real weather + AQI + UV using services/weather.py
            try:
                weather = fetch_current_weather(lat, lon)
                temp = weather['temp']
                humidity = weather['humidity']
                rainfall = weather['rainfall']

                aq = fetch_aqi(lat, lon)
                aqi = aq.get("aqi_index") or 80   # fallback

                uv_data = fetch_onecall_uv(lat, lon)
                uv = uv_data.get("uv") or 5       # fallback

            except Exception as e:
                st.warning("Weather API failed — using placeholders.")
                st.write(e)
                temp, humidity, rainfall, aqi, uv = 25, 60, 0, 80, 5

            # show metrics in left column
            st.metric("🌡️ Temperature (°C)", temp)
            st.metric("💧 Humidity (%)", humidity)
            st.metric("🌫️ AQI", aqi)
            st.metric("🌧️ Rainfall (mm, 1h)", rainfall)
            st.metric("☀️ UV Index", uv)

            # build input dataframe for model
            if model is None or classes is None:
                st.error("❌ Model not found. Run the training script to create the model.")
            else:
                X = pd.DataFrame([{
                    "temperature": temp,
                    "humidity": humidity,
                    "aqi": aqi,
                    "rainfall": rainfall,
                    "uv_index": uv
                }])

                st.session_state.last_X = X.to_dict(orient="records")[0]

                # predict and store only (do NOT render tables or map here)
                try:
                    probs = model.predict_proba(X)[0]
                    results = []
                    for idx, p in enumerate(probs):
                        name = classes[idx] if idx < len(classes) else f"label_{idx}"
                        results.append({"disease": name, "prob": float(p)})
                    results_sorted = sorted(results, key=lambda x: x["prob"], reverse=True)[:5]

                    # --- apply calendar-based multipliers ---
                    mults, matched = get_event_multipliers(EVENT_CALENDAR)

                    # --- SEASONAL MULTIPLIERS ---
                    season_mults, season_name = get_season_multipliers(lat, lon)

                    if matched:
                        st.info("Events affecting risk: " + ", ".join(matched))

                    # apply event multipliers to matching disease keys (case-insensitive substring match)
                    for r in results_sorted:
                        label = r["disease"].lower()
                        for key, factor in mults.items():
                            if key.lower() in label:
                                r["prob"] = min(1.0, r["prob"] * factor)

                    # apply season multipliers
                    if season_mults:
                        st.info(f"Season active: {season_name.replace('_',' ')}")
                        for r in results_sorted:
                            label = r["disease"].lower()
                            for key, factor in season_mults.items():
                                if key.lower() in label:
                                    r["prob"] = min(1.0, r["prob"] * factor)

                    # re-sort after adjustments
                    results_sorted = sorted(results_sorted, key=lambda x: x["prob"], reverse=True)
                    # --- end multipliers ---

                    st.session_state.last_results = results_sorted
                    st.success("✔ Prediction complete!")
                except Exception as e:
                    st.error("❌ Prediction failed. See console for details.")
                    st.write(e)

# RIGHT column: render results/tables/map ONCE (driven by session_state)
with col2:
    st.subheader("Results")

    if st.session_state.last_results:
        # bullet list
        for item in st.session_state.last_results:
            st.write(f"- **{item['disease']}** — {item['prob']*100:.1f}%")

        # results table (single place)
        df_results = pd.DataFrame([{"disease": r["disease"], "probability": r["prob"]} for r in st.session_state.last_results])
        st.write("**Results Table**")
        st.table(df_results.assign(probability=lambda d: (d['probability']*100).round(1).astype(str) + '%'))

        # input features table (single place)
        if st.session_state.last_X:
            st.write("**Model input (features)**")
            st.dataframe(pd.DataFrame([st.session_state.last_X]), width=400)
    else:
        st.info("Enter a location to see predictions.")

    # single map render only
    if st.session_state.last_lat is not None and st.session_state.last_lon is not None:
        m = folium.Map(location=[st.session_state.last_lat, st.session_state.last_lon], zoom_start=10)
        folium.Marker([st.session_state.last_lat, st.session_state.last_lon], tooltip=st.session_state.last_city).add_to(m)
        st_folium(m, width=700, height=450)
    else:
        st.info("Map will appear here after prediction.")
