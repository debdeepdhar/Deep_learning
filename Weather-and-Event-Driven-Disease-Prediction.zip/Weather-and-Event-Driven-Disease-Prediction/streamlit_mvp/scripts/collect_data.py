# scripts/collect_data.py
import pandas as pd
from services.weather import fetch_current_weather, fetch_aqi, fetch_onecall_uv
from services.events import fetch_eventbrite
from geopy.geocoders import Nominatim
import time, os, csv
from dotenv import load_dotenv
load_dotenv(dotenv_path=".env")

LOCATIONS = [
    {"name":"Delhi, India", "lat":28.6139, "lon":77.2090},
    # add more
]

out_rows = []
for loc in LOCATIONS:
    lat = loc["lat"]; lon = loc["lon"]
    weather = fetch_current_weather(lat, lon)
    aqi = fetch_aqi(lat, lon)
    uv = fetch_onecall_uv(lat, lon)
    events = fetch_eventbrite(lat, lon) if os.getenv("EVENTBRITE_TOKEN") else {}
    row = {
        "date": pd.Timestamp.now().strftime("%Y-%m-%d"),
        "location": loc["name"],
        "lat": lat, "lon": lon,
        "temperature": weather["temp"],
        "humidity": weather["humidity"],
        "rainfall": weather["rainfall"],
        "aqi_index": aqi.get("aqi_index"),
        "uv_index": uv.get("uv"),
        "events_count": len(events.get("events", [])) if events else 0
    }
    out_rows.append(row)
    time.sleep(1)  # be polite with API limits

df = pd.DataFrame(out_rows)
os.makedirs("../data/merged", exist_ok=True)
df.to_csv("../data/merged/collected_latest.csv", index=False)
print("Saved collected_latest.csv")
