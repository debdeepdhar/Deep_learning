# test_demo.py
# Simple training script that saves a clean joblib payload:
# {"model": sklearn_model, "classes": [label_names_in_order]}

import os
import joblib
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import LabelEncoder

# Toy dataset (replace with real data later)
data = [
    {"temperature": 35, "humidity": 70, "aqi": 120, "rainfall": 0, "uv_index": 9, "disease": "Heatstroke"},
    {"temperature": 30, "humidity": 85, "aqi": 90,  "rainfall": 150, "uv_index": 4, "disease": "Dengue"},
    {"temperature": 22, "humidity": 60, "aqi": 50,  "rainfall": 0, "uv_index": 2, "disease": "Flu"},
    {"temperature": 28, "humidity": 40, "aqi": 30,  "rainfall": 0, "uv_index": 8, "disease": "Heatstroke"},
    {"temperature": 26, "humidity": 90, "aqi": 100, "rainfall": 200, "uv_index": 3, "disease": "Dengue"},
    {"temperature": 18, "humidity": 55, "aqi": 40,  "rainfall": 0, "uv_index": 1, "disease": "Flu"},
]

df = pd.DataFrame(data)

# Features and target
X = df[['temperature', 'humidity', 'aqi', 'rainfall', 'uv_index']]
y = df['disease']

# Encode labels to integers for training
le = LabelEncoder()
y_enc = le.fit_transform(y)

# Train a RandomForest
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X, y_enc)

# Prepare a clean payload: model + human-readable class list in model's probability order
# We use the label order [0..n-1] mapped back to names
classes_list = le.inverse_transform(range(len(le.classes_))).tolist()

payload = {
    "model": model,
    "classes": classes_list
}

# Ensure model folder exists and save
os.makedirs("model", exist_ok=True)
out_path = os.path.join("model", "disease_predictor_clean.joblib")
joblib.dump(payload, out_path)

print(f"Saved cleaned model payload to: {out_path}")
print("Classes (index -> name):")
for idx, name in enumerate(classes_list):
    print(f"  {idx} -> {name}")
