# services/seasonal.py
from datetime import date

# ----------------------------
# HELPERS
# ----------------------------

def is_india(lat, lon):
    """Rough check to determine if location is in India (simple bounding box)."""
    return 6.0 <= lat <= 35.0 and 68.0 <= lon <= 97.0


def get_month_day():
    """Return (month, day) as integers."""
    today = date.today()
    return today.month, today.day


# ----------------------------
# INDIAN SEASONS (Best-fit)
# ----------------------------

def indian_season():
    """Return the Indian season name based on today's date."""
    m, d = get_month_day()

    # Summer: March 1 to May 31
    if (m == 3 and d >= 1) or (m in [4, 5]):
        return "Summer_India"

    # Monsoon: June 1 to Sep 30
    if (m == 6 and d >= 1) or (m in [7, 8]) or (m == 9 and d <= 30):
        return "Monsoon_India"

    # Post-Monsoon (festive pollution-heavy period): Oct 1 to Oct 31
    if m == 10:
        return "PostMonsoon_India"

    # Winter: Nov 1 to Feb 28
    if (m == 11) or (m == 12) or (m in [1, 2]):
        return "Winter_India"

    return "Unknown_India"


def indian_season_for_month(m):
    """Season lookup for a specific month (used for monthly spikes)."""
    if m in (3, 4, 5):
        return "Summer_India"
    if m in (6, 7, 8, 9):
        return "Monsoon_India"
    if m == 10:
        return "PostMonsoon_India"
    if m in (11, 12, 1, 2):
        return "Winter_India"
    return "Unknown_India"


# ----------------------------
# GLOBAL SEASONS (Hemisphere-based)
# ----------------------------

def global_season(lat):
    """Return global season depending on hemisphere for today's date."""
    m, _ = get_month_day()

    if lat >= 0:   # Northern Hemisphere
        if m in [12,1,2]: return "Winter_Global"
        if m in [3,4,5]:  return "Spring_Global"
        if m in [6,7,8]:  return "Summer_Global"
        if m in [9,10,11]:return "Autumn_Global"
    else:           # Southern Hemisphere
        if m in [12,1,2]: return "Summer_Global"
        if m in [3,4,5]:  return "Autumn_Global"
        if m in [6,7,8]:  return "Winter_Global"
        if m in [9,10,11]:return "Spring_Global"

    return "Unknown_Global"


def global_season_for_month(lat, m):
    """Season lookup for a specific month (monthly spike support)."""
    if lat >= 0:  # Northern Hemisphere
        if m in (12,1,2): return "Winter_Global"
        if m in (3,4,5):  return "Spring_Global"
        if m in (6,7,8):  return "Summer_Global"
        if m in (9,10,11):return "Autumn_Global"
    else:  # Southern Hemisphere
        if m in (12,1,2): return "Summer_Global"
        if m in (3,4,5):  return "Autumn_Global"
        if m in (6,7,8):  return "Winter_Global"
        if m in (9,10,11):return "Spring_Global"

    return "Unknown_Global"


# ----------------------------
# MULTIPLIERS FOR EACH SEASON
# ----------------------------

SEASON_MULTIPLIERS = {
    # --- India ---
    "Summer_India": {
        "heat": 2.5,
        "heatstroke": 2.5,
        "dehydration": 1.8,
        "gastro": 1.2
    },
    "Monsoon_India": {
        "dengue": 2.2,
        "malaria": 1.8,
        "cholera": 1.5,
        "diarrhea": 1.4,
        "fever": 1.2
    },
    "PostMonsoon_India": {
        "asthma": 1.4,
        "respiratory": 1.5,
        "flu": 1.2,
        "pollution": 1.6
    },
    "Winter_India": {
        "flu": 1.5,
        "pneumonia": 1.6,
        "asthma": 1.3,
        "cold": 1.4
    },

    # --- Global ---
    "Summer_Global": {
        "heat": 2.0,
        "heatstroke": 2.0,
        "sunburn": 1.6,
        "dehydration": 1.4
    },
    "Winter_Global": {
        "flu": 1.4,
        "pneumonia": 1.5,
        "asthma": 1.2,
        "cold": 1.3
    },
    "Spring_Global": {
        "allergy": 1.5,
        "asthma": 1.2
    },
    "Autumn_Global": {
        "flu": 1.2,
        "respiratory": 1.2
    }
}


# ----------------------------
# MAIN ENTRY FUNCTIONS
# ----------------------------

def get_season_multipliers(lat, lon):
    """
    Return multipliers for TODAY'S date.
    Used by your app.py during prediction.
    """
    if is_india(lat, lon):
        season = indian_season()
    else:
        season = global_season(lat)

    return SEASON_MULTIPLIERS.get(season, {}), season


def get_season_for_month(lat, lon, month):
    """
    Return (multipliers_dict, season_name) for ANY month.
    Used by the monthly spike chart.
    """
    if is_india(lat, lon):
        season = indian_season_for_month(month)
    else:
        season = global_season_for_month(lat, month)

    return SEASON_MULTIPLIERS.get(season, {}), season
