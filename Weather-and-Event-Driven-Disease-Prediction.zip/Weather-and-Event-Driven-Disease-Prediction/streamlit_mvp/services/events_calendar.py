# services/event_calendar.py
import json
import datetime
from pathlib import Path

DEFAULT_PATH = Path(__file__).resolve().parents[1] / "data" / "events_calendar.json"

def load_event_calendar(path: str = None):
    p = Path(path) if path else DEFAULT_PATH
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)

def get_event_multipliers(calendar: dict, date: datetime.date = None):
    """
    Returns dict mapping effect_key -> factor if applicable on given date.
    e.g. {"dengue": 2.0, "injury":1.3}
    """
    if date is None:
        date = datetime.date.today()
    year = date.year
    month = date.month
    weekday = date.weekday()  # Monday=0 ... Sunday=6

    multipliers = {}
    matching_events = []

    for name, info in calendar.items():
        applies = False

        # months
        if "months" in info and month in info["months"]:
            applies = True

        # years
        if "years" in info:
            if year not in info["years"]:
                applies = False

        # weekdays (special entry for weekend/local)
        if "weekdays" in info:
            if weekday in info["weekdays"]:
                applies = True

        if applies:
            matching_events.append(name)
            for k, v in info.get("effects", {}).items():
                # if same effect occurs multiple times, multiply factors (or choose max)
                existing = multipliers.get(k, 1.0)
                # combine by multiplication (safer than sum)
                multipliers[k] = round(existing * float(v), 3)

    return multipliers, matching_events
