# services/weather.py
import os
import requests
from dotenv import load_dotenv
from datetime import datetime, timezone
load_dotenv(dotenv_path=os.path.join(os.path.dirname(__file__), "..", ".env"))

OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY")

def fetch_current_weather(lat, lon):
    """Returns dict: temp, humidity, rainfall_mm, raw"""
    if not OPENWEATHER_API_KEY:
        raise RuntimeError("OPENWEATHER_API_KEY not set in .env")
    url = f"https://api.openweathermap.org/data/2.5/weather?lat={lat}&lon={lon}&units=metric&appid={OPENWEATHER_API_KEY}"
    r = requests.get(url, timeout=10)
    r.raise_for_status()
    j = r.json()
    temp = j["main"]["temp"]
    humidity = j["main"]["humidity"]
    rainfall = j.get("rain", {}).get("1h", 0)
    return {"temp": temp, "humidity": humidity, "rainfall": rainfall, "raw": j}

def fetch_aqi(lat, lon):
    """Returns AQI index from OpenWeather (1..5) or None on failure"""
    if not OPENWEATHER_API_KEY:
        return {"aqi_index": None, "raw": None}
    url = f"http://api.openweathermap.org/data/2.5/air_pollution?lat={lat}&lon={lon}&appid={OPENWEATHER_API_KEY}"
    try:
        r = requests.get(url, timeout=10)
        r.raise_for_status()
        j = r.json()
        aqi = j.get("list", [{}])[0].get("main", {}).get("aqi", None)
        return {"aqi_index": aqi, "raw": j}
    except requests.HTTPError as exc:
        # Fail gracefully: return None for AQI, keep raw error message
        return {"aqi_index": None, "raw": {"error": str(exc), "status_code": getattr(exc.response, 'status_code', None)}}
    except Exception as exc:
        return {"aqi_index": None, "raw": {"error": str(exc)}}

def fetch_onecall_uv(lat, lon):
    """
    Try OpenWeather OneCall to get current.uvi.
    If OpenWeather OneCall returns 401 or other failure, fall back to Open-Meteo.
    Returns dict: {"uv": float_or_None, "raw": raw_response_or_error}
    """
    # 1) Try OpenWeather One Call
    if OPENWEATHER_API_KEY:
        url = (
            f"https://api.openweathermap.org/data/2.5/onecall?"
            f"lat={lat}&lon={lon}&exclude=minutely,hourly,daily,alerts&appid={OPENWEATHER_API_KEY}"
        )
        try:
            r = requests.get(url, timeout=10)
            r.raise_for_status()
            j = r.json()
            uv = j.get("current", {}).get("uvi", None)
            return {"uv": uv, "raw": j}
        except requests.HTTPError as exc:
            # If we get a 401 or other HTTPError, fall through to fallback
            err = {"error": str(exc), "status_code": getattr(exc.response, "status_code", None)}
        except Exception as exc:
            err = {"error": str(exc)}
    else:
        err = {"error": "OPENWEATHER_API_KEY not set"}

    # 2) Fallback to Open-Meteo (free) — uses hourly uv_index and matches current hour
    try:
        # Open-Meteo endpoint returns hourly uv_index; pick the current hour's value
        om_url = (
            f"https://api.open-meteo.com/v1/forecast?"
            f"latitude={lat}&longitude={lon}&hourly=uv_index&timezone=UTC"
        )
        r2 = requests.get(om_url, timeout=10)
        r2.raise_for_status()
        j2 = r2.json()
        # find the current UTC hour index
        now_utc = datetime.now(timezone.utc).replace(minute=0, second=0, microsecond=0)
        times = j2.get("hourly", {}).get("time", [])
        uv_series = j2.get("hourly", {}).get("uv_index", [])
        if times and uv_series:
            # try to find exact matching time string
            time_str = now_utc.strftime("%Y-%m-%dT%H:00")
            if time_str in times:
                idx = times.index(time_str)
                uv_val = uv_series[idx]
            else:
                # fallback: choose first element (best-effort)
                uv_val = uv_series[0]
            return {"uv": uv_val, "raw": j2}
        else:
            return {"uv": None, "raw": {"error": "no uv data from open-meteo", "openweather_err": err}}
    except Exception as exc:
        # final fallback: return error info but do not raise
        return {"uv": None, "raw": {"openweather_err": err, "open_meteo_err": str(exc)}}
